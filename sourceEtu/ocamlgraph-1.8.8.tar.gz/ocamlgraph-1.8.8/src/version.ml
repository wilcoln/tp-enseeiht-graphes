let version = "1.8.8"
let date = "mardi 17 octobre 2017, 11:24:54 (UTC+0200)"
